alist = [10,35,45,46,345,344,10]

# add an object to the list
alist.append(450)
print("After appending:", alist)
alist.append(456)
print("After appending:", alist)
getcount = alist.count(10)
print("total count of 10 :", getcount)
# extend : passing set of values at a time to the list
alist.extend([65,67,2,4])
print("After extending:", alist)
print("Get index of 35 :", alist.index(35))

# list.insert(where to insert, what to insert)
#              position      , value  
alist.insert(0,5)
print("After inserting :", alist)

# pop : remove the value at that index
alist.pop(4)   ## here 4 in the index
print("After pop operation :", alist)

alist.pop(0)
print("After pop operation :", alist)

## In remove.. we will be passing the value directly
alist.remove(35)  # here 35 is the element in the list
print("After remove operation :", alist)
print(alist)

# reverse the list
alist.reverse()
print("After reversing :", alist)

# sorted - ascending order
alist.sort()
print("After sorting :", alist)

# sorted order - descending
alist.sort(reverse = True)
print("After sorting :", alist)



