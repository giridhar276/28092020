# sting object and it methods
name = "python programming"
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.center(40)) # default is space
print(name.center(40,"*"))

print(name.count('p'))
print(name.endswith('z'))
print(name.endswith('ing'))
print(name.replace("python","ruby"))


string = "I love {} and {}"
print(string.format("python","hadoop"))
print(string.format("1","2"))
print(string.format("apple","mango"))
line = "pythonoraclejavadb"
print(line.split(":"))


name = "python"
print("Length of the string :", len(name))

name = " python    "
print("Length of the string :", len(name))
name = name.strip()  # will remove spaces at both the eends
print("Length of the string :", len(name))



























