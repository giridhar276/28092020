


adict = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(adict)

print(adict["chap1"])  # 10
print(adict["chap100"])  

# ONLY keys
print(adict.keys())

## ONLY values
print(adict.values())

## items
print(adict.items())  # list of tuples

print(adict["chap100"])

print(adict.get("chap100"))
print(adict.get("chap1"))   # 10

adict.pop("chap1")  # both key and value will be removed
print("After pop operation :" , adict)





