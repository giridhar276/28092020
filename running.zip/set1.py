# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 22:00:30 2020

@author: gsripath
"""

aset = {10,10,10,20,20,20,20,20,20,30}
print(aset)

