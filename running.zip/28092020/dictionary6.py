ytag = {
  "kind": "youtube#searchListResponse",
  "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
  "nextPageToken": "CAUQAA",
  "regionCode": "KE",
  "pageInfo": {
    "totalResults": 4249,
    "resultsPerPage": 5
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#channel",
        "channelId": "UCJowOS1R0FnhipXVqEnYU1A"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#video",
        "videoId": "Eqa2nAAhHN0"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfB",
      "id": {
        "kind": "youtube#video",
        "videoId": "IirngItQuVs"
      }
    }
  ]
}
  

for key,value in ytag.items():
    if isinstance(value,str):    
        print(key,value)
    elif isinstance(value,dict):
        for skey,svalue in value.items():
            print(skey,svalue)       
    elif isinstance(value,list):
        for inneritem in value:
            #print(inneritem)
            for skey,svalue in inneritem.items():
                print(skey,svalue)
                
