

print("python programming")

print("spark programming")

print("unix shell scripting")


print(10,20,30)

print("The values are :", 10,20,30)


val = 10
name = 29
aval= 32.4
print("the values are :", val,aval)






