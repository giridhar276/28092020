'''
 Define some list as below

alist = ["google","oracle","microsoft"]


Output:
http://www.google.com
http://www.oracle.com
http://www.microsoft.com
'''

alist = ["google","oracle","microsoft"]

for item in alist:
    #fullly qualified domain name fqdn
    fqdn = "http://www." + item + ".com"
    print(fqdn)
    