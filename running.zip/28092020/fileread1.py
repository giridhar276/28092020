

fobj = open("numbers.txt","r")

for getline in fobj:
    # remove whitespaces
    getline = getline.strip()
    print(getline)

fobj.close()