

name = "python"
print(len(name))


alist = [10,20,30]
print(len(alist))


adict = {"chap1":10 ,"chap2":20}
print(len(adict))