'''
write a program to display the below output

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''
##############  concatenation happens with same object ##

fixed= "192.168.0."

for val in range(1,11):
    ip = fixed +  str(val)
    print(ip)
    
    
'''    
list = [10,10,10,20,30,40,40,40]
write a program to remove the duplicates from the list.
'''
alist = [10,10,10,20,30,40,40,40]
aset = set(alist)
print(list(aset))

print(list(set(alist)))





    