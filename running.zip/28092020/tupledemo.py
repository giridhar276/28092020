atup = (45,5,34,5)
btup = ('java','python','c')
ctup = (45,67,54.4,"hadop",45)

print(atup)
print(btup)


atup[0] = 10000

print("first element :",atup[0])
print("second element:", atup[1])

# iterating with for loop
for val  in atup:
    print(val)

atup = (45,5,34,5)
atup[0] = 3000
print("After modifying :", atup)


for val in range(1,10):
    print(val)