
alist = [10,20,30,40]
blist = ['perl','hadoop','spark','scala']
clist = [34,5,45.4,"java","oracle","unix"]

print(alist)
print("Elements are :", alist)
print("First element :", alist[0])
print(alist[0:3]) #[10,20,30]

print(alist[::-1])
print(alist[-3:-1])  #[20,30]
print(alist[1:3])    #[20,30]

print(alist[0])

alist[0] = 1000
print("After modifying :", alist)

print(alist)

## iterating the list
for val in alist :
    print(val)




