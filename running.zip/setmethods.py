
# set methods

aset = {10,10,20,20,20,20,30}
print(aset)


bset = {30,40,50}
print(bset)

print("Union :", aset.union(bset))
print("Intersection:", aset.intersection(bset))

print("difference", aset.difference(bset))

print(aset.issubset(bset))