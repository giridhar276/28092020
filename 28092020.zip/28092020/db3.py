


import csv
import pymysql

# connect to db
try:
    db = pymysql.connect(host='localhost',port=3307,user='root',password='india@123',database='testdb')
    fobj = open("realestate.csv","r")
    # converting file object to csv object
    reader = csv.reader(fobj)
    cursor = db.cursor()
    for line in reader:
        street= line[0]
        city = line[1]
        query = "insert into realestate values('{}','{}')".format(street,city)
        # execute the query
        cursor.execute(query)
    db.commit()
    db.close()
except (FileNotFoundError,IndexError,TypeError) as err:
    print(err)
except Exception as err:
    print(err)
        


 
    
    
    