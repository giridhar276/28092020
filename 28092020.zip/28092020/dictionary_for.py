book  = {"chap1": ["101","UK","Rita"], "chap2":20 ,"chap3":30 } 

#1st method
for key in book.keys():
    print(key)
    

## 2nd method
for dictvalue in book.values():
    print(dictvalue)
    
    
## display key-value pair
for key,value in book.items():
    print(key,value)
    


adict =    {
     "colors": "red",
     "values": "#f00"
   }

print(adict['colors'])
print(adict['values'])










