

## user defined function
def openfile():
    fobj = open("realestate.csv","r")
    ##
    ##
    fobj.close()


openfile()
openfile()
openfile()
openfile()
openfile()
openfile()
openfile()