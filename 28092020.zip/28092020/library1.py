import math
print(math.floor(45.3))
print(math.ceil(45.3))
print(math.tan(2))


