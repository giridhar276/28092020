# -*- coding: utf-8 -*-
#reading the file using readlines()
# output will be in list format
# .log .conf .txt .csv  .properties
#fobj = open("D:\\data\\info\\customers.txt","r")
fobj = open("customers.txt","r")
print(fobj.readlines())   # in the list format
fobj.close()


#reading the file using read()
# output will be one single string
## No iterations in this code
###### this is least preferred ########
fobj = open("customers.txt","r")
print(fobj.read())
fobj.close()


## empty file
fobj = open("customers_info.txt","w")
fobj.close()