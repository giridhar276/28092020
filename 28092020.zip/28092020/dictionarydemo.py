book  = {"chap1": 10 , "chap2":20 ,"chap3":30 } 


print(book)

print(book["chap1"])  # 10

print(book["chap2"])  # 20

print(book["chap3"])  #30



book  = {"chap1": 10 , "chap2":20 ,"chap3":30 ,"chap1":1000}
# if the key is repeated.. it will be taking the latest value
print(book["chap1"]) 


info  = {"chap1":[10,'Rita','US'] , "chap2":[20,'Gita','UK'] ,"chap3":[30,'Paul','AUS'] }
print(info)
print(info["chap1"])
print(info["chap2"])
print(info["chap3"])

