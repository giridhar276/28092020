fobj = open("realestate.csv","r")
#emptyset
cityset = set()
# processing the data
for getline in fobj:
    # remove whitespaces
    getline = getline.strip()
    output = getline.split(",")
    city = output[1]
    # adding each city to set to capture unique cities
    cityset.add(city)
    
## display output
for city in cityset:
    print(city)

fobj.close()
