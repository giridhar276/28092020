# using csv libary
import csv

# fobj can also be called as
# file object  OR  file handler or file reference
cityset = set()
fobj = open("realestate.csv","r")
# converting file object to csv object
reader = csv.reader(fobj)
## each line will be converted to list automically
for line in reader:
    # adding each city to the set
    cityset.add(line[1])
    
for city in cityset:
    print(city)

fobj.close()