a = 10
b = 20

if a < b :
    print("A is less than B")
else:
    print("B is less than A")
print("out of if")



name = input("Enter any name :")
if name.isupper():
    print("You have entered upper case")
elif name.islower():
    print("You have entered lower case")
    
    
val = 10
if isinstance(val,int):
    print("Object is of type int")
else:
    print("object is someother type")
    
    