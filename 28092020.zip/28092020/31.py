#Write a Python program to display all the files and directories from the current directory.

import os

for file in os.listdir():
    print(file)