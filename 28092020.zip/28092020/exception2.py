try:
    filename = input("Enter any filename :")
    #filename ="realestate.csv"
    fobj = open(filename,"r")
    
    for getline in fobj:
        # remove whitespaces
        getline = getline.strip()
        print(getline) 
    fobj.close()
except FileNotFoundError as err:
    print("File not found error :",err)
except TypeError as err:
    print("Invalid operation", err)
except ValueError as err:
    print("Invalid input",err)
except (IndexError,ArithmeticError,IOError) as err:
    print("Exception occured")
except Exception as err:   # default Exception
    print("Unknown exception :", err)
else:
    output = "python" + "programming"
    print(output)
finally:
    print("this block will be executed all the times")