
#write a program to write all the numbers from 1 to 100 to the file.



## opening the file in write mode
fobj = open("numbers.txt","w")

for val in range(1,101):
    fobj.write(str(val) + "\n" )

## closing the file
fobj.close()
