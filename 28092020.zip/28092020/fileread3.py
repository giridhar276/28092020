
fobj = open("realestate.csv","r")

for getline in fobj:
    # remove whitespaces
    getline = getline.strip()
    output = getline.split(",")
    print("Street  :", output[0])
    print("City    :", output[1])
    print("-----------------------")



fobj.close()

    

