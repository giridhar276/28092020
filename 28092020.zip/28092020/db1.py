

import pymysql

# connect to db
db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='testdb')
print(db)   # It should display some connection string


query = "select * from realestate"

# preparing the cursor
cursor = db.cursor()

# execute the query
cursor.execute(query)

# display the output
for record in cursor.fetchall():
    print(record)
    
    
db.close()
