def read_csv():
    ## your logic


def read_db():
    # logic


def processing():
    # Logic

read_csv()


processing()


read_db()