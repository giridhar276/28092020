# -*- coding: utf-8 -*-
"""
write a program to read some filename from the keyboard(customers.csv) and display its filename and extension separately.

Input:
Enter any filename :  customers.csv

Output:
filename : customers
extension: csv

"""


filename = input("Enter any filename :")
print("you entered :", filename)
output = filename.split(".")
print(output)

print("Filename :", output[0])
print("Extension:", output[1])