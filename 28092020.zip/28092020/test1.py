
import sys


try:
    val = 3 + "hello"
except Exception as err:
    print(err)
    
    print(sys.exc_info())