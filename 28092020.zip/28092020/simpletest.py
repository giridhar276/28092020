


alist = [10,20,30,40,45,3,64,5576,45,6,443,754,436,45,744,74,54,64,365,43,45,46,454,64,536,45]

if 10 in alist:
    print("Exists")
    
    
name  = "python programming"
if "python" in name :
    print("some logic")
    
    
for val in alist:
    print(val)