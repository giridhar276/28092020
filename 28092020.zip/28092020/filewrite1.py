


## file write operation

## opening the file in write mode
fobj = open("customers.txt","w")

fobj.write("python programming\n")

## closing the file
fobj.close()


# fobj = open("D:\\notes\\programs\\customers.txt","w")
fobj = open("D:\\customers.txt","w")

fobj.write("python programming\n")

## closing the file
fobj.close()