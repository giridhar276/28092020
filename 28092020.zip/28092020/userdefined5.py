# fixed arguments

def display(a,b,c):
    print(a,b)

display(10,20,30)