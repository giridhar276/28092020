


color = input("Enter any color :")

if color == "red":
    print("RED")
elif color == "green":
    print("GREEN")
elif color == "blue":
    print("BLUE")
elif color =="black":
    print("BLACK")
else:
    print("Unknown color")