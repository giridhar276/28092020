
import pymysql

# connect to db
db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='testdb')
print(db)   # It should display some connection string

street = "Hitechcity"
city= "Hyderabad"

query = "insert into realestate values('{}','{}')".format(street,city)

# preparing the cursor
cursor = db.cursor()

# execute the query
cursor.execute(query)

# display the output
print(cursor.rowcount , "inserted")

db.commit()
    
    
db.close()
