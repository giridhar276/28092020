## input()
name = input("Enter any name :")
print("you entered  :", name)

## id()  : identify  - some unique reference
val= 10
info = [230,34]
print(id(val))
print(id(info))

## range()
print(list(range(1,11)))
print(list(range(2,20,2)))
print(tuple(range(1,20,2)))

print(type(val))
print(type(info))

# isinstance()  - - used for validating the object
print(isinstance(val,list))
print(isinstance(val,int))
print(isinstance(info,str))

print(max(info))  # 230
print(min(info))  #34
print(sum(info))  #264

val = 100
print(float(val))
print(oct(val))
print(hex(val))

atup = (10,20,30)

alist = list(atup)   # converting to list
alist[0] = 10000
atup  = tuple(alist)  # reconverting back to tuple
print("After modifying :", atup)












