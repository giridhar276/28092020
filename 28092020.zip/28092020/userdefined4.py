def display(a,b):
    print(a,b)

display(10,20,30)



def display(a,b,c):
    print(a,b)

display(10,20)