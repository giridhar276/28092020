fobj = open("realestate.csv","r")
##
##
fobj.close()

fobj = open("realestate.csv","r")
##
##
fobj.close()
fobj = open("realestate.csv","r")
##
##
fobj.close()
fobj = open("realestate.csv","r")
##
##
fobj.close()
fobj = open("realestate.csv","r")
##
##
fobj.close()
fobj = open("realestate.csv","r")
##
##
fobj.close()
fobj = open("realestate.csv","r")
##
##
fobj.close()