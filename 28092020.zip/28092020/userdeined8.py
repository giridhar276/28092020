
def increment(x):
    return x + 1


print(increment(10))


##################
#lambda function
#################
#lambda is equivalent to single line function
# Instead of going with single line function... we can define lambda
# Instead of writing single line function , lambda can be used
# syntax
# functioname = lambda variables : expression
# Advantage : processing of the program increases

########1st example using one object
increment = lambda  x : x + 1
print(increment(10))

####### 2nd example using two objects
add = lambda  x,y : x + y
print(add(10,20))

####### regular way 
def getupper(name):
    return name.upper()
print(getupper("python"))

##### using lambda
getupper = lambda x : x.upper()
print(getupper("python"))



