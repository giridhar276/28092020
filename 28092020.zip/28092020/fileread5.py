# 2nd approach
fobj = open("realestate.csv","r")
citylist = []
# processing the data
for getline in fobj:
    # remove whitespaces
    getline = getline.strip()
    output = getline.split(",")
    city = output[1]

    citylist.append(city)
    
## display output
for city in set(citylist):
    print(city)

fobj.close()