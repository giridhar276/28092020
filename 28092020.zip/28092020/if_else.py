
a = 10
b = 20

if a < b :
    print("A is less than B")
    print("Inside if only")
    print("Still inside if")


print("out of if")