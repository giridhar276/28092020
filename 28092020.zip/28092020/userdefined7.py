
# variable length arguments

# If any object is prefixed with * ..
# it becomes tuple
def display(*values):
    #print(values)
    for val in values:
        print(val)

display(10,10,20,30,40,3,530,3,4323,5,43,53,4343




libraries
-------------











c











)