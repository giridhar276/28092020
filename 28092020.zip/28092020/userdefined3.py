

def display(a,b):
    print(a,b)

display(10,20)