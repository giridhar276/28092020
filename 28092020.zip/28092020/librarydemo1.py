
shutil.

import os

#print(os.listdir())

# display all the files line by line
for file in os.listdir():
    print(file)
    

# today's date
import datetime
print(datetime.datetime.now())


import os
os.remove("numbers.txt")


import shutil
shutil.copy("realestate.csv","D:\\")

