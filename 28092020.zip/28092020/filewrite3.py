#write a program to capture your name from the keyboard and write the output to the file



name = input("Enter any file :")

fobj = open("yourname.txt","w")

fobj.write(name + "\n")

fobj.close()


#write a program to write all the odd numbers from 100 to 1 to the file.

## opening the file in write mode
fobj = open("oddnumbers.txt","w")

for val in range(101,1,-2):
    fobj.write(str(val) + "\n" )

## closing the file
fobj.close()



fobj = open("evennumbers.txt","w")

for val in range(100,0,-2):
    fobj.write(str(val) + "\n" )

## closing the file
fobj.close()
