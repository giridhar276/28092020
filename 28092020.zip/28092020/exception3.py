print("exception handling demo")
print("------------------------")
try:
    i = int(input("Enter first number  :"))
    j = int(input("Enter second number :"))
    k = i/j
    print(k)
except ZeroDivisionError as error:
    print("second value cannot be zero")
    print("System defined error :", error)
except ValueError as error:
    print("please enter string values ")
    print("System defined error :", error )
except :
    print("error occurred")