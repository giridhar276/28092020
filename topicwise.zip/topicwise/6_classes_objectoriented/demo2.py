class Robot:
    def SayHello(self,name1,name2):
        self.name1 = name1
        self.name2 = name2
        print("Hello" + self.name1 + self.name2)
        
 
    

if __name__ == "__main__":
    x = Robot()
    x.SayHello("python","Perl")
 
