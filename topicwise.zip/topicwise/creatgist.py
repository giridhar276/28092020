import getopt, sys, os, errno  
import getpass    
import requests
import json
from requests.auth import HTTPBasicAuth
from requests.auth import HTTPDigestAuth
server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

local_file = "githubtest0.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    "githubtest0.py": {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=HTTPBasicAuth(user,'ec0ba5b0dd69be20f53036ec828a7a9a5781eb12'))
print(r1.json())
