import boto3
import os
bucketName = "ingramgiri"
source = "bar.xlsx"
destination = "bar.xlsx"



s3 = boto3.client('s3')

for file in os.listdir():
    if os.path.isfile(file):
        print("Uploading :",file)
        s3.upload_file(file,bucketName,file)