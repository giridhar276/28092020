



import boto3
ec2 = boto3.resource('ec2', region_name='ap-south-1')

for val in range(1,5):
    instances = ec2.create_instances(MinCount=1, MaxCount=1, ImageId='ami-00e782930f1c3dbc7', InstanceType='t2.micro') # create one instance with a t2.micro instance-type

