import urllib.request
...
# Download the file from `url` and save it locally under `file_name`:
urllib.request.urlretrieve("https://www.python.org/ftp/python/3.5.1/python-3.5.1-amd64-webinstall.exe", "python.exe")

