import re

some_text = 'alpha, beta,,,,gamma delta'
 
alist = list(some_text)

print(alist)
