# helloworld.py

print("Hello world")
