#lists in python

alist = ["python programming",100,45.45,"Giris",45.3]

blist = [12,23,34,45,56]

# to print complete list
print("alist :" , alist )
print("blist :", blist )

# to print first element of the list
print("alist[0] :", alist[0])

# to print elements starting from 2nd till 3rd
print("list[1:3] :", alist[1:3])

# to print elements starting from 3rd element
print("print elements starting from 3rd element :")
print(alist[2:])

# to print list two times
print("list two times :", alist * 2 )

# to print concatenated lists
print("concatenated lists : ", alist + blist )
